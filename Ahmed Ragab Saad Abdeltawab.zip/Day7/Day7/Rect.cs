﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    class Rect : Shape
    {
        public double Length { get; }
        public double Width { get; }

        public Rect(double lengt, double width)
        {
            Length = lengt;
            Width = width;
        }

        public override double CalculateArea()
        {
            return Length * Width;
        }

        public override void Draw()
        {
            Console.WriteLine("Drawing rectangle");
        }
    }
}
