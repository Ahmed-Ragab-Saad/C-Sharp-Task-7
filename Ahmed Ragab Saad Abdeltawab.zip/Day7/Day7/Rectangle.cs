﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    class Rectangle : IShape
    {
        public double Area { get; }

        public void Draw()
        {
            Console.WriteLine("Drawing rectangle");
        }
    }
}
