﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    interface IShape
    {
        #region Properties
        public double Area { get; }
        #endregion

        #region Methods
        public void Draw(); 

        public void PrintDetails()
        {
            Console.WriteLine("Details");
        }

        #endregion
    }
}
