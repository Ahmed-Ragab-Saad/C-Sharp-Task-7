﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    class Car : IMovable
    {
        //--1
        #region Properties
        public int ID { get; set; }
        public string Brand { get; set; }
        public decimal Price { get; set; }
        #endregion

        #region Constructors
        public Car()
        {
            ID = 0;
            Brand = "BMW";
            Price = 100000;
        }
        public Car(int id)
        {
            ID = id;
            Brand = "BMW";
            Price = 100000;
        }
        public Car(int id, string brand)
        {
            ID = id;
            Brand = brand;
            Price = 100000;
        }
        public Car(int id, string brand, decimal price)
        {
            ID = id;
            Brand = brand;
            Price = price;
        }
        #endregion

        #region Methods

        public void Move()
        {
            Console.WriteLine("Car moving");
        }

        public override string ToString()
        {
            return $"Car id is {ID}, Car brand is {Brand}, Car price is {Price}";
        }
        #endregion
    }
}
